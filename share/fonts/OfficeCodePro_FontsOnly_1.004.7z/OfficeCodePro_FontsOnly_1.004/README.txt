Office Code Pro - original version
Office Code Pro D - the zero is dotted instead of a line through it
